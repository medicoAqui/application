package com.example.gabriela.medicoaqui.Activity.Activitys;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.example.gabriela.medicoaqui.Activity.Entities.Medico;
import com.example.gabriela.medicoaqui.Activity.JsonOperators.JSONReader;
import com.example.gabriela.medicoaqui.Activity.Service.HttpConnections;
import com.example.gabriela.medicoaqui.R;
import com.example.gabriela.medicoaqui.Activity.Entities.Consulta;
import com.example.gabriela.medicoaqui.Activity.Activitys.TelaLogin;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;

public class VisualizarHistorico extends AppCompatActivity {

    private static final String TAG = "VisualizarHistorico";

    JSONObject jsonTT = new JSONObject();
    JSONReader jsonReader = new JSONReader();
    HttpConnections http = new HttpConnections();
    static ArrayList<Consulta> lista_minhas_consultas = new ArrayList<Consulta>();

    public static String medico;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_historico);






/*
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }

    private void carregaMinhaAgenda() {

        final JSONObject jsonTT = new JSONObject();

        try {
            jsonTT.put("cliente", TelaLogin.getClientePerfil().getId());
        } catch (JSONException e) {
            e.printStackTrace();
        }


        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String minhaAgendaBD = http.sendPost("http://medicoishere.herokuapp.com/consulta/consultaByDateAndCpfCliente", jsonTT.toString());
                    HashSet<Consulta> minhaAgenda = jsonReader.getMedicosByEspecialidade(medicosBD);
                    HashSet<Medico> medicosEntity = jsonReader.getMedicosByEspecialidadeEntity(medicosBD);
                    lista_medicos.addAll(medicos);
                    //Collections.sort(lista_medicos);
                    lista_medicos_entity.addAll(medicosEntity);
                    lista_medicos.remove("Selecione");
                    lista_medicos.add(0,"Selecione");
                } catch (HttpConnections.MinhaException e) {
                    e.printStackTrace();
                }
            }
        }).start();

    }

}
