package com.example.gabriela.medicoaqui.Activity.Entities;

public class Resposta {

    private String nome;

    public Resposta(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

}
